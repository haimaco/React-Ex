import React from "react";

export class QuizTitle extends React.Component {
  render(){
    return (
        <h1 className="QuizTitle">How do you like front End?</h1>
    )
  }
}