import React from "react";

export class Q1 extends React.Component {
  render(){
    return (
        <h3 className="Q1">how much you love front End?</h3>
    )
  }
}