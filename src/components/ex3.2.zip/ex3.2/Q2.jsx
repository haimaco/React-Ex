import React from "react";

export class Q2 extends React.Component {
  render(){
    return (
        <h3 className="Q2">What is your favourite front end feature/topic?</h3>
    )
  }
}