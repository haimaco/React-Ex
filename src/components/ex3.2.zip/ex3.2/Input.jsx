import React from "react";

export class Q2Input extends React.Component {
  render(){
    return (
        <input className="textInput" type="text" style={{width: 200}}></input>
    )
  }
}