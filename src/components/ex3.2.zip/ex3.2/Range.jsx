import React from "react";

export class Q1Input extends React.Component {
  render(){
    return (
        <input className="rangeInput" type="Range" style={{width: 200}}></input>
    )
  }
}